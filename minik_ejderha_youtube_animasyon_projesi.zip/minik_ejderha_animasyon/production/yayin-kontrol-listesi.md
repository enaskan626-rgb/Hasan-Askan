# Üretim ve yayın kontrol listesi

## Ön hazırlık
- [ ] Pofuduk, Pıtırcık ve Gri Pus için karakter referanslarını oluştur.
- [ ] Renk paletini, oranları ve aksesuarları tek bir referans sayfasında sabitle.
- [ ] Sahne planını üretim aracının desteklediği klip uzunluklarına böl.
- [ ] Her sahne için aynı karakter referanslarını ve genel görsel kilidini kullan.

## Görüntü ve ses
- [ ] Her klipte hareket, yüz, göz, el/pençe ve arka plan hatalarını kontrol et.
- [ ] Klipler arasında kesme veya geçişleri ritme göre ayarla.
- [ ] Türkçe diyalogları zaman kodlarına göre yerleştir.
- [ ] Diyalog, müzik ve efekt ses seviyelerini dengele; konuşmalar her zaman anlaşılır olsun.
- [ ] Telifsiz/uygun lisanslı müzik ve efekt kullan; lisans kanıtlarını sakla.
- [ ] Altyazıları kurgu programında ekle ve yazım kontrolü yap.
- [ ] Son 10 saniyede final duygusunu ve sonraki bölüm merakını test et.

## Dışa aktarma
- [ ] 16:9, 1920×1080, H.264 MP4.
- [ ] Seçilen kare hızı bütün sahnelerde tutarlı.
- [ ] Ses stereo AAC; patlama, clipping veya ani ses sıçraması yok.
- [ ] Başta/sonda yanlışlıkla siyah kare veya üretim aracı filigranı yok.
- [ ] Telefon ekranında küçük resim ve altyazılar okunaklı.

## YouTube
- [ ] Başlık ve açıklama doğru; yanıltıcı vaat yok.
- [ ] Çocuklara yönelik içerik ayarını doğru işaretle.
- [ ] Küçük resmin telif hakları uygun.
- [ ] Yapay üretim içeriği için YouTube'un güncel açıklama/etiket kurallarını kontrol et.
- [ ] Yorum ve gizlilik ayarlarını kanalın hedef kitlesine göre gözden geçir.
- [ ] Yayından sonra ilk 30 saniyedeki izleyici tutma oranını ve tıklanma oranını incele.
