# YouTube yayın paketi

## Başlık seçenekleri
1. Minik Ejderha ve Kaybolan Gökkuşağı 🌈 | Türkçe 3D Çizgi Film
2. Gökkuşağı Nereye Gitti? 🐉 | Pofuduk'un Büyük Macerası
3. Renkleri Kim Sakladı? | Minik Ejderha ile Büyülü Orman

## Açıklama taslağı
Renk Ormanı'nın gökkuşağı kayboldu! 🐉🌈 Minik ejderha Pofuduk ve akıllı tavşan Pıtırcık, renkleri bulmak için büyülü bir maceraya çıkıyor. Peki, renkleri saklayan Gri Pus neden yalnız hissediyor?

Bu özgün animasyon; dostluk, empati ve birlikte çözüm bulmanın önemini anlatır. Ailece iyi seyirler!

#ÇizgiFilm #TürkçeÇizgiFilm #Animasyon #Çocuklar

## Küçük resim önerisi
- Pofuduk'un şaşkın yüzü sol tarafta, büyük ve parlak gökkuşağı sağ tarafta.
- Arka plan: canlı yeşil orman ve temiz mavi gökyüzü.
- En fazla 2–4 büyük kelime: “GÖKKUŞAĞI NEREDE?”
- Yüz ifadeleri büyük, kompozisyon sade ve telefonda okunaklı.
- Yazıyı görsel üretim aracında değil, sonradan tasarım aracında ekleyin.

## Deney önerisi
İlk testte iki başlık/küçük resim varyasyonu kullanın. Sonuçları tıklanma oranı, ilk 30 saniye izleyici tutma ve ortalama izlenme süresiyle değerlendirin. İzlenme sayısı veya viral olma garanti edilemez.
