# Minik Ejderha ve Kaybolan Gökkuşağı
**Tahmini süre:** 4 dakika  
**Tür:** 3D aile/çocuk macerası  
**Duygu akışı:** şaşkınlık → merak → küçük başarısızlıklar → takım çalışması → sıcak final

## Karakterler
- **Pofuduk:** Küçük, mint yeşili bir ejderha. Büyük kehribar gözleri, minik boynuzları, turuncu kanat içleri ve yıldız biçimli kuyruğu vardır. Ateş yerine renkli, parıltılı baloncuklar üfler.
- **Pıtırcık:** Enerjik, krem rengi bir tavşan. Mor sırt çantası taşır; pratik fikirler bulur.
- **Anlatıcı:** Sıcak, neşeli ve net Türkçe ses.

## 00:00–00:20 — Gökkuşağı nereye gitti?
[Parlak bir sabah. Kamera yemyeşil, büyülü ormanın üzerinde süzülür. Tepedeki gökkuşağı bir anda pıt diye söner. Çiçeklerin renkleri solmaya başlar.]

ANLATICI: “Renk Ormanı’nda her sabah gökyüzüne kocaman bir gökkuşağı çizilirdi. Ama bugün… bir şeyler ters gitmişti!”

POFUDUK: “Eee? Gökkuşağım nerede?”

[Pofuduk ağzından üç minik ışıklı baloncuk çıkarır. Baloncuklar patlayınca komik bir ‘pof!’ sesi gelir.]

PITIRCIK: “Belki renklerini kaybetmiştir. Hadi onları bulalım!”

## 00:20–00:50 — İlk ipucu
[Yaprakların üzerinde parlayan üç renkli toz tanesi belirir. Pıtırcık büyüteç gibi yuvarlak bir yaprak tutar.]

PITIRCIK: “Bak! Kırmızı, sarı ve mavi ışıklar ormanın içine gidiyor.”

POFUDUK: “Ben hazırım! Ejderha yürüyüşü!”

[Pofuduk havalı yürümeye çalışır, kök takılır ve yumuşak yosuna poposunun üstüne düşer. İkisi de güler.]

ANLATICI: “Bazen büyük bir macera, küçük bir düşüşle başlar.”

## 00:50–01:25 — Fısıldayan çiçekler
[Dev, renkleri solmuş çiçekler yollarını kapatır. Çiçekler konuşmak yerine başlarını eğer.]

POFUDUK: “Üzülmeyin çiçekler. Size biraz neşe verebilirim!”

[Pofuduk renkli baloncuk üfler. Baloncuklar çiçeklerin etrafında döner ama renkler geri gelmez.]

PITIRCIK: “Tek başına parıltı yetmiyor. Belki çiçeklerin suya ihtiyacı vardır!”

[Bir yaprak kasesiyle dere suyu taşırlar. Çiçekler canlanır; bir tanesi Pofuduk’un burnuna polen kondurur. Pofuduk hapşırır: “Pİ-POF!” Renkli baloncuklar havaya fırlar.]

## 01:25–02:00 — Zıplayan taşlar
[İncecik bir dere üzerinde taşlar sırayla yükselip alçalır. Karşı kıyıda mavi bir ışık görünür.]

PITIRCIK: “Taşlar ritimle hareket ediyor. Ben sayacağım, sen zıpla!”

PITIRCIK: “Bir… iki… üç!”

[Pofuduk yanlış zamanda zıplar ve bir nilüfer yaprağına yumuşakça iner. Yaprak onu yay gibi geri fırlatır. Komik, güvenli bir sekme.]

POFUDUK: “Bu planın bir… zıplama payı varmış!”

[İkisi ritmi birlikte tutturur ve karşıya geçer.]

## 02:00–02:35 — Renklerin saklandığı mağara
[Kristal mağaranın içinde üç ışık küresi görülür. Her küre sönük yanıp söner. Ortada küçük bir gölge değil, minik ve ürkek bir bulutçuk vardır: Gri Pus.]

GRİ PUS: “Ben renkleri çalmadım… sadece herkes gökkuşağına bakarken kimse beni fark etmiyordu. Renkleri sakladım ki orman benimle de oynasın.”

[Pofuduk ve Pıtırcık birbirine bakar. Müzik yumuşar.]

POFUDUK: “Bizi fark etmeni isteriz. Ama renkler gidince herkes üzüldü.”

PITIRCIK: “İstersen bizimle gökkuşağını birlikte tamamlayabilirsin.”

## 02:35–03:15 — Birlikte parlamak
[Gri Pus tereddüt eder. Pofuduk ona bir baloncuk uzatır. Pıtırcık küreleri sırayla havaya kaldırır.]

ANLATICI: “Pofuduk bir şeyi anladı: Birini dışarıda bırakmadan da herkes parlayabilirdi.”

[Üç arkadaş kırmızı, sarı ve mavi ışıkları aynı anda serbest bırakır. Renkli ışık şeritleri mağaranın tavanından ormana uzanır.]

GRİ PUS: “Ben de yardım edebilir miyim?”

POFUDUK: “Tabii! Sen bulutları taşı, biz renkleri!”

[Gri Pus gökyüzüne yükselir ve renkli ışıkların birleşmesi için yumuşak, beyaz bir zemin oluşturur.]

## 03:15–03:45 — Gökkuşağı geri dönüyor
[Gökyüzünde muhteşem bir gökkuşağı yeniden oluşur. Ormanın renkleri canlanır. Çiçekler dans eder, kelebekler döner.]

PITIRCIK: “Başardık!”

POFUDUK: “Hayır, birlikte başardık!”

[Gri Pus utanarak gülümser. Küçük bir yağmur damlası düşer; Pofuduk’un burnuna konar.]

POFUDUK: “Hapşıracağım galiba…”

“Pİ-POF!”

[Bir sürü minik gökkuşağı baloncuğu çıkar. Herkes kahkaha atar.]

## 03:45–04:00 — Son sürpriz
[Üç arkadaş kameraya el sallar. Uzakta bir ağacın arkasında altın renkli, parlayan minik bir yumurta belirir.]

ANLATICI: “Renk Ormanı’nda maceralar hiç bitmez… Peki, bu parlayan yumurtanın içinden kim çıkacak?”

[Parıltı. Neşeli müzik yükselir. Kesme.]

**Son ekran yazısı:** “Bir sonraki macerada görüşürüz!”  
**Not:** Son ekrandaki yazıyı kurgu programında ekleyin; üretken video aracından yazıyı görüntünün içine çizmesini istemeyin.
