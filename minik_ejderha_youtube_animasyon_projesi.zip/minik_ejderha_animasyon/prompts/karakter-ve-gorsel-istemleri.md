# Görsel üretim istemleri
İstemleri kullandığınız görsel/video üretim aracına göre uyarlayın. Önce karakter referanslarını üretip sonraki sahnelerde aynı referansları kullanın.

## Genel görsel kilidi
“Özgün, yüksek kaliteli, renkli 3D aile animasyonu; yumuşak sinematik aydınlatma, doygun ama gözü yormayan renkler, sevimli yuvarlak formlar, okunaklı siluetler, duyguları belirgin yüz ifadeleri, büyülü yemyeşil orman, güvenli ve sıcak atmosfer, temiz kompozisyon, 16:9 yatay geniş kadraj. Karakter tasarımı sahneler boyunca tutarlı. Görüntü içinde yazı, logo, filigran yok.”

## Pofuduk — karakter referansı
“Sevimli küçük mint yeşili bebek ejderha, büyük kehribar gözler, iki minik krem renkli boynuz, turuncu kanat içleri, yıldız biçimli kuyruk ucu, kısa tombul gövde, minik pençeler, parlak pullar ama yumuşak oyuncak benzeri yüzey, sıcak gülümseme. Tam boy karakter sayfası, önden, yandan ve üç çeyrek açı, nötr açık arka plan, renkli 3D aile animasyonu, 16:9.”

## Pıtırcık — karakter referansı
“Sevimli küçük krem renkli tavşan, uzun kulaklar, büyük kahverengi gözler, mor küçük sırt çantası, minik pembe burun, meraklı ve zeki ifade, kısa yumuşak tüyler, tam boy önden ve üç çeyrek açı karakter sayfası, renkli 3D aile animasyonu, nötr açık arka plan.”

## Gri Pus — karakter referansı
“Minik sevimli gri bulut karakter, yumuşak yuvarlak kenarlar, büyük nazik gözler, hafif utangaç gülümseme, çevresinde birkaç ince gümüş parıltı, asla korkutucu değil, renkli 3D aile animasyonu, nötr arka plan.”

## Sahne istemleri
Her sahne isteminin başına genel görsel kilidini ve ilgili karakter tariflerini ekleyin.

1. **Açılış:** “Gün doğumunda büyülü Renk Ormanı, çiy damlalı çiçekler, yüksek ağaçlar, gökyüzünde parlak gökkuşağı; gökkuşağı sihirli bir pırıltıyla aniden söner, çiçeklerin renkleri yavaşça solar; kamera geniş havadan görünümden Pofuduk'un şaşkın yüzüne iner. Çocuk dostu, net aksiyon.”
2. **İpuçları:** “Yaprakların üzerinde kırmızı sarı mavi ışık tozları; Pıtırcık işaret eder; Pofuduk kahramanca yürürken yosunlu köke takılıp yumuşakça oturur, ikisi güler. Komik zamanlama, zarar yok.”
3. **Çiçekler:** “Solgun dev çiçekler, Pofuduk renkli parıltılı baloncuklar üfler; Pıtırcık yaprak kasesiyle dere suyu taşır; çiçekler canlanır ve minik polen Pofuduk'un burnuna konar.”
4. **Dere geçişi:** “Sığ, berrak dere üzerinde ritimle hareket eden yuvarlak taşlar; Pıtırcık sayar, Pofuduk yanlış anda zıplayıp büyük nilüfer yaprağına yumuşakça iner, yaprak onu güvenli ve komik biçimde sektirir; ikisi birlikte karşıya geçer.”
5. **Kristal mağara:** “Pastel mavi ve mor kristallerle aydınlanan güvenli büyülü mağara, havada üç sönük renk küresi; ortada küçük, utangaç gri bulut karakter Gri Pus; Pofuduk ve Pıtırcık merakla dinler.”
6. **İş birliği:** “Pofuduk parıltılı baloncuk verir, Pıtırcık üç renk küresini kaldırır, Gri Pus bulut gibi yukarı süzülür; kırmızı, sarı ve mavi ışık şeritleri birleşerek mağaranın tavanına uzanır; umutlu, büyülü dönüşüm.”
7. **Gökkuşağı:** “Geniş görkemli manzara; gökyüzünde canlı gökkuşağı yeniden oluşur, çiçekler canlanır, kelebekler dans eder; üç arkadaş sevinçle birbirine bakar; Pofuduk hapşırır ve minik renkli baloncuklar çıkar.”
8. **Gizemli yumurta:** “Üç arkadaş orman açıklığında el sallarken kamera yavaşça altın ışık saçan küçük bir yumurtaya döner; yumurta bir kez hafifçe parlar, gizemli ama sevimli, devam hikâyesine davet.”

## Negatif istem / kaçınılacaklar
“korku, şiddet, tehditkâr yüzler, karanlık dehşet atmosferi, gerçekçi ateş, yaralanma, ekstra uzuvlar, bozuk yüz, değişen göz rengi, değişen kostüm, titreyen doku, aşırı kamera sarsıntısı, okunaksız metin, altyazı, logo, filigran.”

## Ses üretim notu
- Anlatıcı: Türkçe, sıcak ve canlı; kelimeleri net telaffuz etsin.
- Pofuduk: genç, neşeli, hafif komik; anlaşılır ve abartısız.
- Pıtırcık: enerjik ve akıllı; hızlı ama anlaşılır.
- Gri Pus: yumuşak, çekingen, nazik.
- Müzik: özgün, enstrümantal, çocuk dostu; diyalogların önüne geçmesin.
